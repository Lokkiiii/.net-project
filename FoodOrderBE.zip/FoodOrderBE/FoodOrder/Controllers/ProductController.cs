﻿using FoodOrder.DataAccess.Models;
using FoodOrder.DataAccess.Providers;

using Microsoft.AspNetCore.Mvc;

namespace FoodOrder.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class ProductController : Controller
    {
        
        //Products
        [Route("ListProducts")]
        [HttpGet]

        public List<ProductMst> ListProducts()
        {
            using (var dbContext = new FoodSystemContext())
            {
                return dbContext.ProductMsts.ToList();
            }
        }
        [Route("InsertProducts")]
        [HttpPost]

        

        [Route("UpdateProducts")]
        [HttpPost]
        public APIResponse UpdateProduct(ProductMst productMst)
        {
            try
            {
                using (var dbContext = new FoodSystemContext())
                {
                    var product = (from p in dbContext.ProductMsts
                                   where p.Pname == productMst.Pname
                                   select p).FirstOrDefault();
                    product.Price = productMst.Price;
                    dbContext.ProductMsts.Update(product);
                    dbContext.SaveChanges();
                }

            }
            catch
            {
                throw;
            }
            return new APIResponse() { status = "success" };
        }
        [Route("DeleteProducts")]
        [HttpPost]
        public APIResponse DeleteProduct(ProductMst productMst)
        {
            try
            {
                using (var dbContext = new FoodSystemContext())
                {
                    var product = (from p in dbContext.ProductMsts
                                   where p.Pname == productMst.Pname
                                   select p).FirstOrDefault();
                    dbContext.ProductMsts.Remove(product);
                    dbContext.SaveChanges();
                }
                return new APIResponse() { status = "success" };
            }
            catch
            {
                throw;
            }
        }
    }
}
