﻿using OnlineFoodOrder;
using System;

namespace Consoletest;